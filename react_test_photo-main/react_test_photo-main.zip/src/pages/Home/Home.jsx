/** @jsxImportSource @emotion/react */
import * as S from "./style";

function Home() {
    return (
        <div css={S.layout}>
            REACT_TEST
        </div>
    );
}

export default Home;